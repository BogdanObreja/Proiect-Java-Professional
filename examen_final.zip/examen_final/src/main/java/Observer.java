public interface Observer {
    void subscribe (Subject subject);
    void update (String news);
}
